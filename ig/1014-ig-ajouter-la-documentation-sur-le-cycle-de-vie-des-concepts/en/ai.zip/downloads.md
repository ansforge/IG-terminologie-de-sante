# Téléchargements et usages - Terminologies de Santé v1.15.0

## Téléchargements et usages

 
There is no translation page available for the current page, so it has been rendered in the default language 

Téléchargements et usage

L'implementation guide contient un package [téléchargeable ici](package.tgz) permettant de valider les instances par rapport aux profils qu'il contient.

Pour cela, il suffit de télécharger le [package.tgz](package.tgz) et l'importer dans un serveur, par exemple sur hapi en suivant ce [script python](https://github.com/nmdp-bioinformatics/igloader) open source.

Vous pourrez ensuite utiliser l'opération [$validate](https://www.hl7.org/fhir/resource-operation-validate.html) pour valider les instances de ressource contre un profil issu de cette spécification.

Ensemble des ressources téléchargeables :

* [L'ensemble de la specification (zip)](full-ig.zip)
* [Package (tgz)](package.tgz)
* [JSON Définitions (zip)](definitions.json.zip)
* [JSON Exemples (zip)](examples.json.zip)
* [XML Definitions (zip)](definitions.xml.zip)
* [XML Exemples (zip)](examples.ttl.zip)
* [Turtle Définitions](definitions.ttl.zip)

