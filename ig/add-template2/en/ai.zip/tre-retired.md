# Terminologies (Retired) - Terminologies de Santé v1.10.0

## Terminologies (Retired)

 
There is no translation page available for the current page, so it has been rendered in the default language 

Vous touverez ici la liste des terminologies à l'etat "retired".

| | |
| :--- | :--- |
| Name | Description |
| [TRE_A09_DICOMuidRegistry](CodeSystem-TRE-A09-DICOMuidRegistry.md) | DICOM UID Registry |
| [TRE_R214_SpecialiteUnite](CodeSystem-TRE-R214-SpecialiteUnite.md) | Spécialité d'unité |
| [TRE_R215_UniteTemps](CodeSystem-TRE-R215-UniteTemps.md) | Unité de temps |
| [TRE_R222_MediaTypeCorpsCDANonStructure](CodeSystem-TRE-R222-MediaTypeCorpsCDANonStructure.md) | Identifiant des modèles de CDA non structurés |
| [TRE_R232_TypeFermetureEJ](CodeSystem-TRE-R232-TypeFermetureEJ.md) | Type de fermeture de l'entité juridique FINESS |
| [TRE_R233_TypeFermetureEG](CodeSystem-TRE-R233-TypeFermetureEG.md) | Type de fermeture de l'entité géographique FINESS |
| [TRE_R277_CategorieActiviteSanitaireRegulee](CodeSystem-TRE-R277-CategorieActiviteSanitaireRegulee.md) | Types d'activités autorisées |
| [TRE_R301_SourceInformationInstallation](CodeSystem-TRE-R301-SourceInformationInstallation.md) | Sources d'information possible concernant l'installation de l'activité sociale |
| [TRE_R35_TypeVoie](CodeSystem-TRE-R35-TypeVoie.md) | Type de voie |
| [TRE_R46_SpecialiteConcoursHospitalier](CodeSystem-TRE-R46-SpecialiteConcoursHospitalier.md) | Spécialité de concours hospitalier |
| [TRE_R75_InseeNAFrev2Niveau5](CodeSystem-TRE-R75-InseeNAFrev2Niveau5.md) | Sous-classes de la Nomenclature d'Activités Française - INSEE |

