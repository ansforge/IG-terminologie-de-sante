# JDV_J154_TypeGlucose_ENS - Terminologies de Santé v1.10.0

## ValueSet: JDV_J154_TypeGlucose_ENS 

 
JDV pour caractériser le type de glucose 

 **References** 

Ce jeu de valeurs n'est pas utilisé ici ; il peut être utilisé autre part (par exemple dans les spécifications et / ou implémentations qui utilisent ce contenu)

###  Recherche en live sur le SMT 

Indiquer un mot clé puis taper sur "enter" :

```
Requête sur le SMT
```

### Définition logique (CLD)

 

### Expansion

-------

 [Description du (des) tableau(x) ci-dessus](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "JDV-J154-TypeGlucose-ENS",
  "meta" : {
    "versionId" : "14",
    "lastUpdated" : "2026-07-06T19:05:16.184+02:00",
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "language" : "fr-FR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
    "valuePeriod" : {
      "start" : "2021-04-30T12:00:00+01:00"
    }
  }],
  "url" : "https://mos.esante.gouv.fr/NOS/JDV_J154-TypeGlucose-ENS/FHIR/JDV-J154-TypeGlucose-ENS",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.2.250.1.213.1.1.5.609"
  }],
  "version" : "20250728120000",
  "name" : "JDV_J154_TypeGlucose_ENS",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-07-23T12:00:00+01:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "description" : "JDV pour caractériser le type de glucose",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "2345-7",
        "display" : "Glucose [Masse/Volume] Sérum/Plasma ; Numérique"
      },
      {
        "code" : "4548-4",
        "display" : "Hémoglobine A1c/hémoglobine totale [Fraction massique] Sang ; Numérique"
      },
      {
        "code" : "99504-3",
        "display" : "Glucose [Masse/Volume] Liquide interstitiel ; Numérique"
      }]
    },
    {
      "system" : "https://smt.esante.gouv.fr/fhir/CodeSystem/terminologie-cisis",
      "concept" : [{
        "code" : "MED-972",
        "display" : "Index de gestion de glycémie (IGG)"
      }]
    }]
  }
}

```
