# European Medical device nomenclature - Terminologies de Santé v1.10.0

## CodeSystem: European Medical device nomenclature 

 
La nomenclature européenne des dispositifs médicaux (EMDN) est la nomenclature que doivent utiliser les fabricants pour enregistrer leurs dispositifs médicaux dans EUDAMED, base de données européenne sur les dispositifs médicaux. Il s'agit d'alimenter le système européen d’identification des dispositifs fondé sur un identifiant unique du dispositif (IUD) pour en faciliter la traçabilité. 

Ce système de codes est référencé dans la définition des ensembles de valeurs suivants :

* [JDV_J145_MethodBodyWeight_ENS](ValueSet-JDV-J145-MethodBodyWeight-ENS.md)
* [JDV_J146_MethodBodyHeight_ENS](ValueSet-JDV-J146-MethodBodyHeight-ENS.md)
* [JDV_J147_MethodHeartrate_ENS](ValueSet-JDV-J147-MethodHeartrate-ENS.md)
* [JDV_J150_MethodBP_ENS](ValueSet-JDV-J150-MethodBP-ENS.md)
* [JDV_J152_MethodBodyTemperature_ENS](ValueSet-JDV-J152-MethodBodyTemperature-ENS.md)
* [JDV_J155_MethodGlucoseSanguin_ENS](ValueSet-JDV-J155-MethodGlucoseSanguin-ENS.md)
* [JDV_J156_MethodGlucoseInterstitiel_ENS](ValueSet-JDV-J156-MethodGlucoseInterstitiel-ENS.md)
* [JDV_J158_MethodStepsByDay_ENS](ValueSet-JDV-J158-MethodStepsByDay-ENS.md)
* [JDV_J275_EMDN_UPNOS](ValueSet-JDV-J275-EMDN-UPNOS.md)
* [JDV Defaillance Materielle CISIS](ValueSet-jdv-defaillance-materielle-cisis.md)
* [JDV Mesure Type Verre Delivre CISIS](ValueSet-jdv-mesure-type-verre-delivre-cisis.md)
* [JDV Mesure Type Verre Prescrit CISIS](ValueSet-jdv-mesure-type-verre-prescrit-cisis.md)
* [JDV Prothese Objet Personnel CISIS](ValueSet-jdv-prothese-objet-personnel-cisis.md)
* [JDV Type Sonde Gastrique CISIS](ValueSet-jdv-type-sonde-gastrique-cisis.md)
* [JDV UFCV Materiel Implente CISIS](ValueSet-jdv-ufcv-materiel-implante-cisis.md)
* [JDV UFCV Modele Valve CISIS](ValueSet-jdv-ufcv-modele-valve-cisis.md)
* [JDV UFCV Polarite Sonde CISIS](ValueSet-jdv-ufcv-polarite-sonde-cisis.md)
* [JDV UFCV Type Dispositif Cardiaque CISIS](ValueSet-jdv-ufcv-type-dispositif-cardiaque-cisis.md)
* [JDV UFCV Type Endoprothese CISIS](ValueSet-jdv-ufcv-type-endoprothese-cisis.md)
* [JDV UFCV Type Valve CISIS](ValueSet-jdv-ufcv-type-valve-cisis.md)

-------

 [Description du (des) tableau(x) ci-dessus](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "terminologie-emdn",
  "meta" : {
    "versionId" : "3",
    "lastUpdated" : "2025-03-20T13:52:13.373+00:00",
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablecodesystem"]
  },
  "url" : "https://smt.esante.gouv.fr/terminologie-emdn",
  "identifier" : [{
    "use" : "usual",
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.2.250.1.213.2.68"
  },
  {
    "use" : "secondary",
    "system" : "https://smt.esante.gouv.fr/",
    "value" : "terminologie-emdn"
  }],
  "version" : "v1.2",
  "name" : "EMDN",
  "title" : "European Medical device nomenclature",
  "status" : "active",
  "experimental" : false,
  "date" : "2022-04-28T00:00:00+00:00",
  "publisher" : "Agence du numérique en santé",
  "description" : "La nomenclature européenne des dispositifs médicaux (EMDN) est la nomenclature que doivent utiliser les fabricants pour enregistrer leurs dispositifs médicaux dans EUDAMED, base de données européenne sur les dispositifs médicaux. Il s'agit d'alimenter le système européen d’identification des dispositifs fondé sur un identifiant unique du dispositif (IUD) pour en faciliter la traçabilité.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "copyright" : "[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/legalcode)",
  "valueSet" : "https://smt.esante.gouv.fr/terminologie-emdn?vs",
  "content" : "not-present",
  "count" : 8344,
  "filter" : [{
    "code" : "root",
    "operator" : ["="],
    "value" : "True or false."
  },
  {
    "code" : "deprecated",
    "operator" : ["="],
    "value" : "True or false."
  },
  {
    "code" : "imported",
    "operator" : ["="],
    "value" : "True or false"
  }],
  "property" : [{
    "code" : "type",
    "uri" : "http://purl.org/dc/elements/1.1/type",
    "description" : "Type fonctionnel d'un concept",
    "type" : "string"
  },
  {
    "code" : "parent",
    "uri" : "http://hl7.org/fhir/concept-properties#parent",
    "description" : "Codes des parents du concept courant",
    "type" : "code"
  },
  {
    "code" : "child",
    "uri" : "http://hl7.org/fhir/concept-properties#child",
    "description" : "Codes des enfants du concept courant",
    "type" : "code"
  },
  {
    "code" : "imported",
    "description" : "Indicates if the concept is imported from another code system.",
    "type" : "boolean"
  },
  {
    "code" : "root",
    "description" : "Indicates if this concept is a root concept (i.e. Thing is equivalent or a direct parent).",
    "type" : "boolean"
  }]
}

```
