# International Classification of Diseases for Oncology, version 3. - Terminologies de Santé v1.15.0

## CodeSystem: International Classification of Diseases for Oncology, version 3. 

 
International Classification of Diseases for Oncology, version 3. For more information see http://www.who.int/classifications/icd/adaptations/oncology/en/. 

Ce système de codes est référencé dans la définition des ensembles de valeurs suivants :

* [JDV Morphologie CISIS](ValueSet-jdv-morphologie-cisis.md)

-------

 [Description du (des) tableau(x) ci-dessus](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "icd-o-3",
  "meta" : {
    "versionId" : "1",
    "lastUpdated" : "2026-01-07T10:12:48.197+01:00"
  },
  "url" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113883.6.43.1"
  }],
  "version" : "2.0.1",
  "name" : "IcdO3",
  "title" : "International Classification of Diseases for Oncology, version 3.",
  "status" : "active",
  "experimental" : false,
  "date" : "2019-03-20T00:00:00-04:00",
  "publisher" : "TBD - External Body",
  "contact" : [{
    "name" : "World Health Organization (WHO)"
  }],
  "description" : "International Classification of Diseases for Oncology, version 3. For more information see http://www.who.int/classifications/icd/adaptations/oncology/en/.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "caseSensitive" : true,
  "content" : "not-present"
}

```
