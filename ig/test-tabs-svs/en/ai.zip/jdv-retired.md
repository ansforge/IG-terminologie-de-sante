# Jeux de valeurs (Retired) - Terminologies de Santé v1.15.0

## Jeux de valeurs (Retired)

 
There is no translation page available for the current page, so it has been rendered in the default language 

Vous touverez ici la liste des JDV à l'etat "retired".

| | |
| :--- | :--- |
| Name | Description |
| [JDV_TRE_R222_MediaTypeCorpsCDANonStructure](ValueSet-TRE-R222-MediaTypeCorpsCDANonStructure-all.md) | JDV avec l'ensemble des codes actifs de la TRE_R222_MediaTypeCorpsCDANonStructure |
| [JDV_J114_Pays_ENREG](ValueSet-JDV-J114-Pays-ENREG.md) | Référentiel dérivé des pays provenant de la norme INSEE pour ENREG |
| [JDV_J123_Pays_MDPH](ValueSet-JDV-J123-Pays-MDPH.md) | Toute la nomenclature des codes pays auquel on ajoute le code applicatif r "non renseigné" |
| [JDV_J129_CategorieEtablissement_RASS](ValueSet-JDV-J129-CategorieEtablissement-RASS.md) | Catégorie d'établissement du RASS |
| [JDV_J12_CiviliteTitre_CISIS](ValueSet-JDV-J12-CiviliteTitre-CISIS.md) | Titre civilité - CI-SIS |
| [JDV_J131_CategorieActiviteSanitaireRegulee_RASS](ValueSet-JDV-J131-CategorieActiviteSanitaireRegulee-RASS.md) | Catégorie des activités sanitaires régulées dans le RASS |
| [JDV_J136_DisciplineEquipementSocial_RASS](ValueSet-JDV-J136-DisciplineEquipementSocial-RASS.md) | Disciplines d'équipement pour le social dans le RASS |
| [JDV_J137_Clientele_RASS](ValueSet-JDV-J137-Clientele-RASS.md) | Population prise en charge par l'établissement dans le cadre |
| [JDV_J148_ReferenceRangeAppliesTo_CISIS](ValueSet-JDV-J148-ReferenceRangeAppliesTo-CISIS.md) | JDV pour le champ d'application de l'intervalle de référence |
| [JDV_J153_TypeDiabete_ENS](ValueSet-JDV-J153-TypeDiabete-ENS.md) | JDV pour caractériser le type de diabète dans l'extension DiabetisType |
| [JDV_J167_DepartementOM_EPARS](ValueSet-JDV-J167-DepartementOM-EPARS.md) | Département pour saisie dans EPARS |
| [JDV_J168_Pays_EPARS](ValueSet-JDV-J168-Pays-EPARS.md) | Pays pour EPARS |
| [JDV_J237_RegionOM_ROR](ValueSet-JDV-J237-RegionOM-ROR.md) | Région Outre-Mer et Monaco |
| [JDV_J247_Pays_ROR](ValueSet-JDV-J247-Pays-ROR.md) | Référentiel des codes pays provenant du COG INSEE - ROR |
| [JDV_J248_DepartementOM_ROR](ValueSet-JDV-J248-DepartementOM-ROR.md) | Département (outre-mer et Monaco inclus) - ROR |
| [JDV_J261_SourceInformationInstallation_RASS](ValueSet-JDV-J261-SourceInformationInstallation-RASS.md) | Sources d'information possible concernant l'installation de l'activité sociale du RASS |
| [JDV_J280_CIM10ATIH_UPNOS](ValueSet-JDV-J280-CIM10ATIH-UPNOS.md) | Termes CIM 10 utilisés |
| [JDV_J48_ProfessionNonPS_CISIS](ValueSet-JDV-J48-ProfessionNonPS-CISIS.md) | Jeux de Valeurs des professions/spécialités des Non Ps |
| [JDV_J69_ActiviteOperationnelle_Santefr](ValueSet-JDV-J69-ActiviteOperationnelle-Santefr.md) | Activités opérationnelles de Santé.fr |
| [JDV_J70_Equipement_Santefr](ValueSet-JDV-J70-Equipement-Santefr.md) | Equipements Santé.fr |
| [JDV_J74_Pays_RASS](ValueSet-JDV-J74-Pays-RASS.md) | Pays (codes INSEE) du RASS |
| [JDV_J83_AutoriteEnregistrement_RASS](ValueSet-JDV-J83-AutoriteEnregistrement-RASS.md) | Autorités d'enregistrement des acteurs de santé du RASS |
| [JDV_J84_DepartementOM_RASS](ValueSet-JDV-J84-DepartementOM-RASS.md) | Départements (outre-mer et Monaco inclus) pour le RASS |
| [JDV_J93_RegionOM_RASS](ValueSet-JDV-J93-RegionOM-RASS.md) | Régions (outre-mer et Monaco inclus) dans le RASS |
| [JDV_J99_InseeNAFrav2Niveau5_RASS](ValueSet-JDV-J99-InseeNAFrav2Niveau5-RASS.md) | Sous-classes de la Nomenclature Activités Française (INSEE) des prof du RASS |

