# JDV_J213_CapaciteSavoirFaire_ROR - Terminologies de Santé v1.15.0

## ValueSet: JDV_J213_CapaciteSavoirFaire_ROR 

 
Capacité (savoir-faire) 

 **References** 

Ce jeu de valeurs n'est pas utilisé ici ; il peut être utilisé autre part (par exemple dans les spécifications et / ou implémentations qui utilisent ce contenu)

###  Recherche en live sur le SMT 

Indiquer un mot clé puis taper sur "enter" :

```
Requête sur le SMT
```

### Définition logique (CLD)

 

### Expansion

-------

 [Description du (des) tableau(x) ci-dessus](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "JDV-J213-CapaciteSavoirFaire-ROR",
  "meta" : {
    "versionId" : "5",
    "lastUpdated" : "2026-07-06T19:05:56.455+02:00",
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "language" : "fr-FR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
    "valuePeriod" : {
      "start" : "2022-08-26T12:00:00+01:00"
    }
  }],
  "url" : "https://mos.esante.gouv.fr/NOS/JDV_J213-CapaciteSavoirFaire-ROR/FHIR/JDV-J213-CapaciteSavoirFaire-ROR",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.2.250.1.213.3.4.45"
  }],
  "version" : "20220826120000",
  "name" : "JDV_J213_CapaciteSavoirFaire_ROR",
  "status" : "active",
  "experimental" : false,
  "date" : "2022-08-26T12:00:00+01:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "description" : "Capacité (savoir-faire)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://mos.esante.gouv.fr/NOS/TRE_R43-CapaciteSavoirFaire/FHIR/TRE-R43-CapaciteSavoirFaire",
      "concept" : [{
        "code" : "CAPA01",
        "display" : "Addictologie clinique (CAPA)"
      },
      {
        "code" : "CAPA02",
        "display" : "Aide médicale urgente (CAPA)"
      },
      {
        "code" : "CAPA03",
        "display" : "Allergologie (CAPA)"
      },
      {
        "code" : "CAPA04",
        "display" : "Angéiologie (CAPA)"
      },
      {
        "code" : "CAPA05",
        "display" : "Evaluation et Traitement de la douleur (CAPA)"
      },
      {
        "code" : "CAPA06",
        "display" : "Gérontologie (CAPA)"
      },
      {
        "code" : "CAPA07",
        "display" : "Hydrologie et Climatologie médicales (CAPA)"
      },
      {
        "code" : "CAPA08",
        "display" : "Médecine aérospatiale (CAPA)"
      },
      {
        "code" : "CAPA09",
        "display" : "Médecine de catastrophe (CAPA)"
      },
      {
        "code" : "CAPA10",
        "display" : "Médecine et Biologie du sport (CAPA)"
      },
      {
        "code" : "CAPA11",
        "display" : "Médecine de santé au travail et Prévention des risques professionnels (CAPA)"
      },
      {
        "code" : "CAPA12",
        "display" : "Médecine pénitentiaire (CAPA)"
      },
      {
        "code" : "CAPA13",
        "display" : "Médecine tropicale (CAPA)"
      },
      {
        "code" : "CAPA14",
        "display" : "Pratiques médico-judiciaires (CAPA)"
      },
      {
        "code" : "CAPA15",
        "display" : "Technologie transfusionnelle (CAPA)"
      },
      {
        "code" : "CAPA16",
        "display" : "Toxicomanies et Alcoologies (CAPA)"
      }]
    }]
  }
}

```
